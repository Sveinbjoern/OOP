/*
  ==============================================================================

    PlaylistComponent.h
    Created: 9 Mar 2022 4:03:40pm
    Author:  Me

  ==============================================================================
*/

#pragma once

#include <JuceHeader.h>
#include <set>
#include <fstream>
#include "Track.h"

//==============================================================================
/*
*/
class PlaylistComponent  :  public juce::Component,
                            public juce::TableListBoxModel,
                            public juce::Button::Listener
{
public:
    PlaylistComponent(juce::Button::Listener* _ButtonListner);
    ~PlaylistComponent() override;
    
    //========================================================
    //juce functions
    void buttonClicked(juce::Button* button)override;
    void paint (juce::Graphics&) override;
    void resized() override;
    juce::Component* refreshComponentForCell(int rowNumber, int columnId, bool isRowSelcted, juce::Component* exisitingComponentToUpdate ) override;

    /**adds a file to the set setOfTracks*/
    bool addToSetOfTracks( const juce::File& audioTrack);
    /**adds a track to the vector tracks*/
    void addTrack(Track* track);

    //getters
    Track* getTrack( juce::File& audioFile);
    int getTrackIndex(const juce::File& audioFile);
    Track* getTrack(int index);
    std::vector<Track*>& getSearchedTracks();
    Track* getSearchedTrack(int index);

    //setter
    void setSearchedTracks(juce::String&);
    void setSearchedTracksToDefault();

    //Filemanagement funcitons
    void saveToPlaylist(Track* track);
    void loadPlaylist();
    void removeFromPlaylist(const juce::String );
    void deleteTrack(int index);
    




    void tableListBoxUpdate();

private:

    std::string currentPlaylistFile;

    bool checkValidPlaylist();
    int binarySearchInsertLocation(int& start, int& end, int& Current, juce::String& fullPath);
    int binarySearch(int& start, int& end, int& Current,  juce::String& fullPath);
    int getNumRows() override;
    void paintRowBackground(juce::Graphics& g, int rowNumber, int width, int height, bool rowIsSelected) override;
    void paintCell(juce::Graphics& g, int rowNumber, int columnId, int width, int height, bool rowIsSelected) override;

    juce::Button::Listener* mainComponentButtonListener;

    /**
    * Sort and add track to the tracks vector sorted by alphabetical order of full path name
    */
    void addTracks(const juce::StringArray& s);
    /**
    * Set of juce::Strings keeps an overview of what tracks we already have in the playlist
    */ 
    std::set<juce::String> setOfTracks;
    /** 
    *All track information stored in one container of Track objects
    */
    std::vector<Track*> tracks;
    std::vector<Track*> searchedTracks;

    std::vector<int> ints;

    // The table list box is inherited from juce and gives a very functional and working table
    juce::TableListBox tableListBox;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(PlaylistComponent)

};
